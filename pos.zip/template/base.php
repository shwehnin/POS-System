<?php

function con(){
    return mysqli_connect("localhost","root","","pos");
}

define("URL","http://".$_SERVER["SERVER_NAME"]."/pos/");
define("ASSET",URL."assets");

