<?php include "base.php"; ?>
<?php include "functions.php"; ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Point Of Sale</title>
    <link rel="stylesheet" href="<?php echo ASSET; ?>/css/bootstrap.min.css">
    <script src="<?php echo ASSET; ?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo ASSET; ?>/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo ASSET; ?>/css/style.css">
    <link rel="stylesheet" href="assets/data%20table/dataTables.bootstrap4.min.css">
    <script src="assets/data%20table/jquery.dataTables.min.js"></script>
    <script src="assets/data%20table/dataTables.bootstrap4.min.js"></script>
</head>
<body>